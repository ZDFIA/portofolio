import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Zap, Code, Cog, Users } from 'lucide-react';

export function AboutSection() {
  const highlights = [
    {
      icon: Cog,
      title: "Control Engineering",
      description: "Specialized in control systems, automation, and electrical engineering applications"
    },
    {
      icon: Zap,
      title: "Renewable Energy",
      description: "Experience with photovoltaic systems and solar energy monitoring technologies"
    },
    {
      icon: Code,
      title: "Technology Integration",
      description: "Skilled in Python, machine learning, web development, and IoT applications"
    },
    {
      icon: Users,
      title: "Leadership Excellence",
      description: "Extensive organizational experience with proven coordination and management skills"
    }
  ];

  return (
    <section id="about" className="py-20 bg-background engineering-grid">
      <div className="max-w-6xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl lg:text-4xl mb-6 text-foreground">About Me</h2>
          <div className="w-20 h-1 bg-tech-blue-700 mx-auto mb-8 tech-glow"></div>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            As an upcoming graduate in Electrical Engineering from Universitas Andalas (GPA: 3.94/4.00), I combine 
            strong technical expertise with extensive leadership experience. My professional background includes 
            internship at PT Semen Padang and diverse organizational roles, while my projects span renewable energy 
            systems, machine learning applications, and IoT-based predictive maintenance solutions.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {highlights.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="p-6 h-full hover:shadow-lg transition-shadow duration-300 border-0 bg-card hover:bg-tech-blue-200 group neon-border tech-shadow">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 bg-tech-blue-200 rounded-full flex items-center justify-center mb-4 group-hover:bg-tech-blue-300 transition-colors duration-300 tech-glow">
                    <item.icon className="w-8 h-8 text-tech-blue-800" />
                  </div>
                  <h3 className="text-lg mb-3 text-card-foreground">{item.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{item.description}</p>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <Card className="p-8 tech-gradient-secondary border-0 neon-border">
            <p className="text-lg text-muted-foreground leading-relaxed max-w-4xl mx-auto">
              My experience spans from hands-on engineering work during my internship at PT Semen Padang to 
              developing modern web applications and leading various organizational initiatives. I thrive in 
              collaborative environments where technical expertise meets creative problem-solving, and I'm 
              excited to contribute to innovative projects that make a meaningful impact.
            </p>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}