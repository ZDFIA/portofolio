import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Mail, Phone, MapPin, Github, Linkedin, ExternalLink } from 'lucide-react';

export function ContactSection() {
  const contactInfo = [
    {
      icon: Mail,
      label: "Email",
      value: "fadlyihsanandanny@gmail.com",
      href: "mailto:fadlyihsanandanny@gmail.com",
      color: "from-blue-500 to-blue-600"
    },
    {
      icon: Phone,
      label: "Phone",
      value: "Available upon request",
      href: "#",
      color: "from-green-500 to-green-600"
    },
    {
      icon: MapPin,
      label: "Location",
      value: "Jokotua Secretariat, Jalan Street No. 19, Lolong Belanti, North Padang, Padang, West Sumatera, Indonesia",
      href: "#",
      color: "from-red-500 to-red-600"
    },
    {
      icon: Linkedin,
      label: "LinkedIn",
      value: "fadlyihsanandanny",
      href: "https://www.linkedin.com/in/fadlyihsanandanny",
      color: "from-blue-600 to-blue-700"
    },
    {
      icon: Github,
      label: "GitHub / Portfolio",
      value: "github.com/fadlyihsan",
      href: "https://github.com/fadlyihsan",
      color: "from-gray-700 to-gray-800"
    }
  ];

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl lg:text-4xl mb-6 text-gray-900">Get In Touch</h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto mb-8"></div>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Ready to discuss opportunities in electrical engineering, web development, 
            or collaborative projects? I'd love to hear from you.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="lg:col-span-2"
          >
            <Card className="p-8 h-full bg-gradient-to-br from-blue-50 to-white border-0 shadow-lg">
              <h3 className="text-2xl mb-6 text-gray-900">Let's Connect</h3>
              <p className="text-gray-700 mb-8 leading-relaxed">
                I'm always open to discussing new opportunities, innovative projects, 
                or sharing insights about engineering and technology. Whether you're 
                looking for a fresh perspective on electrical engineering challenges 
                or need someone who can bridge the gap between technical systems and 
                modern web applications, I'd love to connect.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <p className="text-gray-700">Available for full-time opportunities</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <p className="text-gray-700">Open to freelance and consulting projects</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <p className="text-gray-700">Interested in collaborative research</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <p className="text-gray-700">Available for speaking engagements</p>
                </div>
              </div>
              
              <div className="mt-8 p-6 bg-white rounded-lg border border-blue-100">
                <h4 className="text-lg mb-3 text-gray-900">Areas of Interest</h4>
                <div className="grid grid-cols-2 gap-2">
                  <span className="text-sm text-gray-600">• Control Systems</span>
                  <span className="text-sm text-gray-600">• Web Development</span>
                  <span className="text-sm text-gray-600">• Industrial Automation</span>
                  <span className="text-sm text-gray-600">• IoT Applications</span>
                  <span className="text-sm text-gray-600">• Machine Learning</span>
                  <span className="text-sm text-gray-600">• System Integration</span>
                </div>
              </div>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <Card className="p-6 h-full bg-white border-0 shadow-lg">
              <h4 className="text-lg mb-6 text-gray-900 text-center">Contact Information</h4>
              <div className="space-y-4">
                {contactInfo.map((item, index) => (
                  <motion.a
                    key={item.label}
                    href={item.href}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg hover:bg-blue-50 transition-all duration-300 group"
                    target={item.href.startsWith('http') ? '_blank' : undefined}
                    rel={item.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                  >
                    <div className={`w-10 h-10 bg-gradient-to-r ${item.color} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                      <item.icon className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs text-gray-500 uppercase tracking-wide">{item.label}</p>
                      <p className="text-sm text-gray-900 group-hover:text-blue-600 transition-colors duration-300">
                        {item.value}
                      </p>
                    </div>
                    {item.href.startsWith('http') && (
                      <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-blue-600 transition-colors duration-300" />
                    )}
                  </motion.a>
                ))}
              </div>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
                viewport={{ once: true }}
                className="mt-8"
              >
                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={() => window.open('mailto:fadlyihsan.andanny@email.com', '_blank')}
                >
                  <Mail className="w-4 h-4 mr-2" />
                  Send Email
                </Button>
              </motion.div>
            </Card>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <Card className="p-8 bg-gradient-to-r from-gray-50 to-blue-50 border-0">
            <p className="text-gray-700 italic">
              "Innovation happens when engineering meets creativity, and technology serves humanity."
            </p>
            <p className="text-blue-600 mt-4">— Fadly Ihsan Andanny, S.T.</p>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}