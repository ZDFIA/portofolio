import { motion } from 'motion/react';
import { Card } from './ui/card';
import { GraduationCap, Award, Star } from 'lucide-react';

export function EducationSection() {
  const universitasAchievements = [
    "Recipient of PKM-GT (Student Creative Program – Written Idea) Incentive, awarded by the Ministry of Education and Culture, Indonesia (2021)",
    "Syiar Staff, Islamic Studies Forum of Engineering (FORISTEK) (2018-2019)",
    "Academic Staff, Islamic Studies Forum of Engineering (FORISTEK) (2019-2020)",
    "Internal Audit Staff, Student Executive Board (BEM KM) (2020-2021)",
    "Operational Coordinator, Neo Telemetri (2021-2022)"
  ];

  const highSchoolAchievements = [
    "Bronze Prize in English Proficiency Competition Grade 10-12 in the PCCST Academic Festival and Science Fair 2016 at Princess Chulabhorn's College, Chalung, Meuang, Satun District, Satun, Thailand"
  ];

  return (
    <section className="py-20 bg-tech-blue-100 tech-pattern">
      <div className="max-w-6xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl lg:text-4xl mb-6 text-foreground">Education</h2>
          <div className="w-20 h-1 bg-tech-blue-700 mx-auto mb-8 tech-glow"></div>
        </motion.div>

        <div className="grid lg:grid-cols-1 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <Card className="p-8 bg-card border-0 tech-shadow neon-border">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-16 h-16 bg-tech-blue-200 rounded-full flex items-center justify-center flex-shrink-0 tech-glow">
                  <GraduationCap className="w-8 h-8 text-tech-blue-800" />
                </div>
                <div>
                  <h3 className="text-xl mb-2 text-card-foreground">Bachelor of Electrical Engineering</h3>
                  <p className="text-tech-blue-800 mb-2">Universitas Andalas</p>
                  <p className="text-muted-foreground mb-1">Limau Manis Street, Pauh, Padang, West Sumatera, Indonesia</p>
                  <p className="text-muted-foreground">Aug 2018 - Jul 2025</p>
                </div>
              </div>
              
              <div className="tech-gradient-secondary p-4 rounded-lg mb-6 neon-border">
                <div className="flex items-center gap-2 mb-2">
                  <Star className="w-5 h-5 text-tech-blue-800" />
                  <span className="text-card-foreground">Academic Performance</span>
                </div>
                <p className="text-2xl text-tech-blue-800 tech-glow">GPA: 3.94/4.00</p>
              </div>
              
              <div className="mb-6">
                <h4 className="text-lg mb-4 text-card-foreground">University Achievements & Leadership</h4>
                <div className="space-y-3">
                  {universitasAchievements.map((achievement, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: 20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                      viewport={{ once: true }}
                      className="flex items-start gap-3 p-3 tech-gradient-accent rounded-lg hover:bg-tech-blue-300 transition-colors duration-300"
                    >
                      <div className="w-2 h-2 bg-tech-blue-800 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-muted-foreground text-sm leading-relaxed">{achievement}</p>
                    </motion.div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-lg mb-4 text-card-foreground">Specialization Areas</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="tech-gradient-accent p-3 rounded-lg text-center neon-border">
                    <p className="text-sm text-muted-foreground">Control Engineering</p>
                  </div>
                  <div className="tech-gradient-accent p-3 rounded-lg text-center neon-border">
                    <p className="text-sm text-muted-foreground">Automation</p>
                  </div>
                  <div className="tech-gradient-accent p-3 rounded-lg text-center neon-border">
                    <p className="text-sm text-muted-foreground">Power Systems</p>
                  </div>
                  <div className="tech-gradient-accent p-3 rounded-lg text-center neon-border">
                    <p className="text-sm text-muted-foreground">Electronics</p>
                  </div>
                </div>
              </div>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <Card className="p-8 bg-card border-0 tech-shadow neon-border">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-16 h-16 bg-tech-blue-200 rounded-full flex items-center justify-center flex-shrink-0 tech-glow">
                  <Award className="w-8 h-8 text-tech-blue-800" />
                </div>
                <div>
                  <h3 className="text-xl mb-2 text-card-foreground">Senior High School, Science</h3>
                  <p className="text-tech-blue-800 mb-2">SMAN 1 Dumai</p>
                  <p className="text-muted-foreground mb-1">Soekarno-Hatta Street, Bukit Jil, Dumai Selatan, Dumai, Riau, Indonesia</p>
                  <p className="text-muted-foreground">Aug 2015 - May 2018</p>
                </div>
              </div>
              
              <div className="tech-gradient-secondary p-4 rounded-lg mb-6 neon-border">
                <div className="flex items-center gap-2 mb-2">
                  <Star className="w-5 h-5 text-tech-blue-800" />
                  <span className="text-card-foreground">Academic Performance</span>
                </div>
                <p className="text-2xl text-tech-blue-800 tech-glow">Score: 89.00/100.00</p>
              </div>
              
              <div>
                <h4 className="text-lg mb-4 text-card-foreground">High School Achievements</h4>
                <div className="space-y-3">
                  {highSchoolAchievements.map((achievement, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: 20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                      viewport={{ once: true }}
                      className="flex items-start gap-3 p-3 tech-gradient-accent rounded-lg hover:bg-tech-blue-300 transition-colors duration-300"
                    >
                      <div className="w-2 h-2 bg-tech-blue-800 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-muted-foreground text-sm leading-relaxed">{achievement}</p>
                    </motion.div>
                  ))}
                </div>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}