import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Building2, Users, Laptop, Lightbulb } from 'lucide-react';

export function ExperienceSection() {
  const highlights = [
    {
      icon: Building2,
      title: "Engineering Excellence",
      description: "Applied theoretical knowledge to real-world industrial processes and systems"
    },
    {
      icon: Users,
      title: "Team Collaboration",
      description: "Worked effectively with cross-functional teams and senior engineers"
    },
    {
      icon: Laptop,
      title: "IT Integration",
      description: "Leveraged technology solutions to optimize engineering workflows"
    },
    {
      icon: Lightbulb,
      title: "Problem Solving",
      description: "Developed innovative approaches to complex technical challenges"
    }
  ];

  return (
    <section className="py-20 bg-background engineering-grid">
      <div className="max-w-6xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl lg:text-4xl mb-6 text-foreground">Work Experience</h2>
          <div className="w-20 h-1 bg-tech-blue-700 mx-auto mb-8 tech-glow"></div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="lg:col-span-2"
          >
            <Card className="p-8 h-full tech-gradient-secondary border-0 tech-shadow neon-border">
              <div className="flex items-start gap-6 mb-6">
                <div className="w-20 h-20 bg-tech-blue-200 rounded-xl flex items-center justify-center flex-shrink-0 tech-glow">
                  <Building2 className="w-10 h-10 text-tech-blue-800" />
                </div>
                <div>
                  <h3 className="text-2xl mb-2 text-card-foreground">Internship</h3>
                  <p className="text-tech-blue-800 text-lg mb-2">PT Semen Padang</p>
                  <p className="text-muted-foreground mb-2">Padang, Indonesia</p>
                  <p className="text-muted-foreground mb-4">Indonesia's first cement company established in 1910, part of PT Semen Indonesia (Persero) Tbk (SIG)</p>
                  <div className="inline-block px-3 py-1 bg-tech-blue-800 text-tech-blue-950 rounded-full text-sm tech-glow">
                    Mar 2022 - Aug 2022
                  </div>
                </div>
              </div>
              
              <div className="space-y-4 mb-6">
                <div>
                  <h4 className="text-lg mb-3 text-card-foreground">Key Responsibilities & Achievements</h4>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-tech-blue-800 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-muted-foreground">Experienced in punctuality and discipline in completing tasks</p>
                    </li>
                    <li className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-tech-blue-800 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-muted-foreground">Proficient in knowledge and applications within the field of Electrical Engineering</p>
                    </li>
                    <li className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-tech-blue-800 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-muted-foreground">Able to work effectively in a team environment</p>
                    </li>
                    <li className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-tech-blue-800 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-muted-foreground">Strong communication skills, both clear and effective</p>
                    </li>
                    <li className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-tech-blue-800 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-muted-foreground">Skilled in utilizing information technology to support work efficiency</p>
                    </li>
                    <li className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-tech-blue-800 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-muted-foreground">Actively engaged in self-development and continuous learning</p>
                    </li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-card p-4 rounded-lg border border-tech-blue-600 neon-border">
                <p className="text-muted-foreground italic">
                  "This internship at Indonesia's pioneering cement company provided invaluable hands-on experience 
                  in applying electrical engineering principles to industrial operations, while developing strong 
                  professional skills in a challenging and dynamic work environment."
                </p>
              </div>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <Card className="p-6 h-full bg-card border-0 tech-shadow neon-border">
              <h4 className="text-lg mb-6 text-card-foreground text-center">Skills Developed</h4>
              <div className="space-y-4">
                {highlights.map((item, index) => (
                  <motion.div
                    key={item.title}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="flex items-start gap-3 p-3 tech-gradient-accent rounded-lg hover:bg-tech-blue-300 transition-colors duration-300"
                  >
                    <div className="w-8 h-8 bg-tech-blue-200 rounded-full flex items-center justify-center flex-shrink-0 tech-glow">
                      <item.icon className="w-4 h-4 text-tech-blue-800" />
                    </div>
                    <div>
                      <h5 className="text-sm mb-1 text-card-foreground">{item.title}</h5>
                      <p className="text-xs text-muted-foreground">{item.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}