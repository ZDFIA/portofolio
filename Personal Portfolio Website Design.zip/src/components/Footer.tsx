import { motion } from 'motion/react';
import { Mail, Linkedin, Github, Heart } from 'lucide-react';

export function Footer() {
  const socialLinks = [
    {
      icon: Mail,
      href: 'mailto:fadlyihsan.andanny@email.com',
      label: 'Email'
    },
    {
      icon: Linkedin,
      href: 'https://linkedin.com/in/fadly-ihsan-andanny',
      label: 'LinkedIn'
    },
    {
      icon: Github,
      href: 'https://github.com/fadlyihsan',
      label: 'GitHub'
    }
  ];

  return (
    <footer className="bg-tech-blue-50 text-foreground py-12 tech-pattern border-t border-tech-blue-600">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl mb-4">Fadly Ihsan Andanny, S.T.</h3>
            <p className="text-muted-foreground leading-relaxed">
              Electrical Engineer & Web Developer passionate about bridging 
              engineering precision with modern digital solutions.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h4 className="text-lg mb-4">Quick Links</h4>
            <div className="space-y-2">
              <a href="#about" className="block text-muted-foreground hover:text-tech-blue-800 transition-colors duration-300">About Me</a>
              <a href="#projects" className="block text-muted-foreground hover:text-tech-blue-800 transition-colors duration-300">Projects</a>
              <a href="#skills" className="block text-muted-foreground hover:text-tech-blue-800 transition-colors duration-300">Skills</a>
              <a href="#contact" className="block text-muted-foreground hover:text-tech-blue-800 transition-colors duration-300">Contact</a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
          >
            <h4 className="text-lg mb-4">Connect With Me</h4>
            <div className="flex space-x-4">
              {socialLinks.map((link) => (
                <motion.a
                  key={link.label}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors duration-300"
                >
                  <link.icon className="w-5 h-5" />
                </motion.a>
              ))}
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          viewport={{ once: true }}
          className="border-t border-gray-800 pt-8 flex flex-col md:flex-row items-center justify-between"
        >
          <p className="text-gray-400 text-sm">
            © 2024 Fadly Ihsan Andanny. All rights reserved.
          </p>
          <div className="flex items-center gap-2 text-gray-400 text-sm mt-4 md:mt-0">
            <span>Made with</span>
            <Heart className="w-4 h-4 text-red-500" />
            <span>and engineering precision</span>
          </div>
        </motion.div>
      </div>
    </footer>
  );
}