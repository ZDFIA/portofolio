import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Users, Crown, Target, Megaphone } from 'lucide-react';

export function OrganizationalSection() {
  const experiences = [
    {
      organization: "Neo Telemetri",
      role: "Operational Coordinator",
      period: "Jul 2021 - Jun 2022",
      location: "Universitas Andalas, Padang, Indonesia",
      description: "A university-level student activity unit at Andalas University that focuses on Information Technology (IT).",
      responsibilities: [
        "Conducted monitoring and evaluation of operational management",
        "Facilitated operational meetings to ensure effective coordination",
        "Served as facilitator in organizational upgrading and development programs",
        "Organized and delivered Basic Operational Training for members",
        "Actively involved in IESO support and internal organizational activities",
        "Facilitated performance improvement programs and documented achievements"
      ],
      skills: ["Operational Management", "Leadership", "Coordination", "Training"],
      icon: Target,
      color: "from-blue-400 to-indigo-500"
    },
    {
      organization: "BEM KM UNAND",
      role: "Internal Audit Staff",
      period: "Sep 2019 - Aug 2020",
      location: "Universitas Andalas, Padang, Indonesia",
      description: "The highest student executive body, functioning as the student government at the university level.",
      responsibilities: [
        "Supervised and monitored the performance of organizational board members, ensuring responsibilities were properly fulfilled",
        "Provided necessary reminders and disciplinary actions to maintain high standards of organizational effectiveness"
      ],
      skills: ["Audit", "Supervision", "Organizational Management", "Accountability"],
      icon: Crown,
      color: "from-green-400 to-blue-500"
    },
    {
      organization: "FORISTEK",
      role: "Academic Staff",
      period: "Sep 2019 - Aug 2020",
      location: "Universitas Andalas, Padang, Indonesia",
      description: "A student activity unit at the Faculty of Engineering, Andalas University, that focuses on religious and spiritual development.",
      responsibilities: [
        "Supervised and enhanced the academic performance of engineering students at Andalas University, with a particular focus on guiding and supporting members of Foristek in their educational growth"
      ],
      skills: ["Academic Supervision", "Mentoring", "Student Development", "Leadership"],
      icon: Users,
      color: "from-purple-400 to-pink-500"
    },
    {
      organization: "FORISTEK",
      role: "Syiar Staff",
      period: "Sep 2018 - Aug 2019",
      location: "Universitas Andalas, Padang, Indonesia",
      description: "A student activity unit at the Faculty of Engineering, Andalas University, that focuses on religious and spiritual development.",
      responsibilities: [
        "Promoted awareness and understanding of Islamic values among engineering students",
        "Provided reminders and guidance to encourage spiritual growth within the student community"
      ],
      skills: ["Community Outreach", "Spiritual Guidance", "Communication", "Event Organization"],
      icon: Users,
      color: "from-purple-400 to-pink-500"
    },
    {
      organization: "Mosque Youth Organization",
      role: "Social Staff",
      period: "Aug 2017 - Jul 2018",
      location: "Masjid Al-Hidayah, Dumai, Indonesia",
      description: "A youth community based at Al-Hidayah Mosque, Dumai, focusing on religious, educational, and social activities.",
      responsibilities: [
        "Engaged in social and community service activities within the mosque environment"
      ],
      skills: ["Community Service", "Social Work", "Religious Activities", "Youth Leadership"],
      icon: Users,
      color: "from-green-400 to-cyan-500"
    },
    {
      organization: "SMOTHER",
      role: "Video Editor",
      period: "Jan 2017 - Dec 2017",
      location: "SMAN 1 Dumai, Dumai, Indonesia",
      description: "Smother is a student media organization that focuses on journalism, media production, and creative content.",
      responsibilities: [
        "Edited video documentation, news reports, and other multimedia content as part of the Smother media organization"
      ],
      skills: ["Video Editing", "Media Production", "Creative Content", "Technical Skills"],
      icon: Megaphone,
      color: "from-orange-400 to-red-500"
    },
    {
      organization: "OSIS",
      role: "Staff of Internal Affairs",
      period: "Jan 2016 - Dec 2016",
      location: "SMAN 1 Dumai, Dumai, Indonesia",
      description: "The official student organization within the school serves as a platform for students to develop leadership, responsibility, and teamwork.",
      responsibilities: [
        "Coordinated the Internal Affairs Department within the Student Council",
        "Prepared and organized equipment for OSIS and school events to ensure smooth execution of activities"
      ],
      skills: ["Event Coordination", "Internal Affairs", "Equipment Management", "Student Leadership"],
      icon: Crown,
      color: "from-blue-400 to-purple-500"
    }
  ];

  return (
    <section className="py-20 bg-background tech-pattern">
      <div className="max-w-6xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl lg:text-4xl mb-6 text-foreground">Organizational Experience</h2>
          <div className="w-20 h-1 bg-tech-blue-700 mx-auto mb-8 tech-glow"></div>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Extensive leadership experience across university and high school organizations, 
            developing strong management, coordination, and technical skills.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {experiences.map((exp, index) => (
            <motion.div
              key={`${exp.organization}-${exp.role}-${index}`}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="p-6 h-full bg-card border-0 tech-shadow hover:shadow-xl transition-all duration-300 group hover:-translate-y-1 neon-border">
                <div className="flex items-start gap-4 mb-4">
                  <div className={`w-12 h-12 bg-gradient-to-r ${exp.color} rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300 tech-glow`}>
                    <exp.icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl mb-1 text-card-foreground group-hover:text-tech-blue-800 transition-colors duration-300">
                      {exp.organization}
                    </h3>
                    <p className="text-tech-blue-800 mb-1">{exp.role}</p>
                    <p className="text-muted-foreground text-sm mb-1">{exp.period}</p>
                    <p className="text-muted-foreground text-xs">{exp.location}</p>
                  </div>
                </div>
                
                <p className="text-muted-foreground mb-4 leading-relaxed text-sm">
                  {exp.description}
                </p>

                <div className="mb-4">
                  <h4 className="text-sm mb-2 text-card-foreground">Key Responsibilities</h4>
                  <ul className="space-y-1">
                    {exp.responsibilities.map((resp, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <div className="w-1 h-1 bg-tech-blue-800 rounded-full mt-2 flex-shrink-0"></div>
                        <p className="text-muted-foreground text-xs leading-relaxed">{resp}</p>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h4 className="text-sm mb-3 text-card-foreground">Key Skills Developed</h4>
                  <div className="flex flex-wrap gap-2">
                    {exp.skills.map((skill) => (
                      <Badge 
                        key={skill} 
                        variant="secondary" 
                        className="bg-tech-blue-200 text-tech-blue-800 hover:bg-tech-blue-300 hover:text-tech-blue-900 transition-colors duration-300"
                      >
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          viewport={{ once: true }}
          className="mt-16"
        >
          <Card className="p-8 tech-gradient-secondary border-0 tech-shadow neon-border">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-xl mb-4 text-card-foreground">Leadership Philosophy</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Through diverse organizational experiences from high school to university level, I've developed 
                  a leadership approach that emphasizes coordination, accountability, and continuous improvement 
                  in both technical and interpersonal domains.
                </p>
              </div>
              <div>
                <h3 className="text-xl mb-4 text-card-foreground">Core Values</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-card p-3 rounded-lg text-center tech-shadow neon-border">
                    <p className="text-sm text-muted-foreground">Coordination</p>
                  </div>
                  <div className="bg-card p-3 rounded-lg text-center tech-shadow neon-border">
                    <p className="text-sm text-muted-foreground">Accountability</p>
                  </div>
                  <div className="bg-card p-3 rounded-lg text-center tech-shadow neon-border">
                    <p className="text-sm text-muted-foreground">Innovation</p>
                  </div>
                  <div className="bg-card p-3 rounded-lg text-center tech-shadow neon-border">
                    <p className="text-sm text-muted-foreground">Excellence</p>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}