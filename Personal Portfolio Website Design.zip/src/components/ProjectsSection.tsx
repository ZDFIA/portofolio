import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ExternalLink, Calendar, Zap, Truck, Globe, BarChart3 } from 'lucide-react';

export function ProjectsSection() {
  const projects = [
    {
      title: "Photovoltaic (PV) Monitoring System",
      year: "2021",
      description: "Comprehensive monitoring system for photovoltaic solar panel installations with real-time data acquisition, performance analytics, and efficiency tracking capabilities.",
      technologies: ["Arduino", "IoT", "Solar Energy", "Data Analytics", "Monitoring Systems"],
      icon: Zap,
      color: "from-yellow-400 to-orange-500"
    },
    {
      title: "Delivery Management System Application",
      year: "2023",
      description: "Full-stack web application designed for comprehensive delivery operations management with advanced route optimization and real-time package tracking capabilities.",
      technologies: ["React", "Node.js", "Database Management", "GPS Integration", "Web Development"],
      icon: Truck,
      color: "from-green-400 to-blue-500"
    },
    {
      title: "Prototype AHSP Web Application",
      year: "2024",
      description: "Advanced prototype web application for Analysis of Unit Price Work (AHSP) in construction projects, featuring cost estimation algorithms and project management tools.",
      technologies: ["Web Development", "Database Design", "Cost Analysis", "Construction Management", "UI/UX Design"],
      icon: Globe,
      color: "from-purple-400 to-pink-500"
    },
    {
      title: "Performance Forecasting of Genset at Pondok Pesantren Harakatul Qur'an using Convolutional Neural Network Method",
      year: "2025",
      description: "Advanced machine learning project utilizing Convolutional Neural Networks to predict generator set performance and optimize maintenance schedules for religious educational institutions.",
      technologies: ["Python", "TensorFlow", "CNN", "Predictive Analytics", "Machine Learning"],
      icon: BarChart3,
      color: "from-blue-400 to-indigo-500"
    },
    {
      title: "Development of a Predictive Maintenance Device for Production Machines",
      year: "2025",
      description: "Innovative IoT-based predictive maintenance system designed to monitor production machine health and predict maintenance needs using advanced sensor technology and data analytics.",
      technologies: ["IoT", "Predictive Maintenance", "Sensor Technology", "Industrial Automation", "Data Analytics"],
      icon: BarChart3,
      color: "from-indigo-400 to-purple-500"
    }
  ];

  return (
    <section className="py-20 bg-tech-blue-100 engineering-grid">
      <div className="max-w-6xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl lg:text-4xl mb-6 text-foreground">Featured Projects</h2>
          <div className="w-20 h-1 bg-tech-blue-700 mx-auto mb-8 tech-glow"></div>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            A showcase of innovative engineering projects spanning renewable energy systems, 
            web development, machine learning, and predictive maintenance applications.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="p-6 h-full bg-card border-0 tech-shadow hover:shadow-xl transition-all duration-300 group hover:-translate-y-1 neon-border">
                <div className="flex items-start gap-4 mb-4">
                  <div className={`w-12 h-12 bg-gradient-to-r ${project.color} rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300 tech-glow`}>
                    <project.icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-xl text-card-foreground group-hover:text-tech-blue-800 transition-colors duration-300">
                        {project.title}
                      </h3>
                      <ExternalLink className="w-4 h-4 text-muted-foreground group-hover:text-tech-blue-800 transition-colors duration-300" />
                    </div>
                    <div className="flex items-center gap-2 mb-3">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">{project.year}</span>
                    </div>
                  </div>
                </div>
                
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {project.description}
                </p>
                
                <div className="flex flex-wrap gap-2">
                  {project.technologies.map((tech) => (
                    <Badge 
                      key={tech} 
                      variant="secondary" 
                      className="bg-tech-blue-200 text-tech-blue-800 hover:bg-tech-blue-300 transition-colors duration-300"
                    >
                      {tech}
                    </Badge>
                  ))}
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <Card className="p-8 bg-gradient-to-r from-blue-50 to-white border-0 shadow-lg">
            <h3 className="text-xl mb-4 text-gray-900">Project Philosophy</h3>
            <p className="text-gray-700 leading-relaxed max-w-3xl mx-auto">
              Each project represents a commitment to bridging theoretical knowledge with practical solutions. 
              From IoT-enabled monitoring systems to machine learning applications, I focus on creating 
              technology that solves real-world problems while maintaining engineering excellence and 
              user-centered design principles.
            </p>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}