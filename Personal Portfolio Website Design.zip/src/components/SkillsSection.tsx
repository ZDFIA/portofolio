import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { Cog, Code, Users, MessageSquare, Monitor, Wrench } from 'lucide-react';

export function SkillsSection() {
  const skillCategories = [
    {
      title: "Electrical Engineering",
      icon: Cog,
      color: "from-blue-500 to-indigo-600",
      skills: [
        { name: "Control Engineering", level: 92 },
        { name: "Power Systems", level: 88 },
        { name: "Industrial Automation", level: 85 },
        { name: "Electronic Circuit Design", level: 90 },
        { name: "PV/Solar Systems", level: 87 }
      ]
    },
    {
      title: "Programming & Development",
      icon: Code,
      color: "from-green-500 to-blue-600",
      skills: [
        { name: "Python", level: 88 },
        { name: "Machine Learning (CNN)", level: 85 },
        { name: "Web Development", level: 83 },
        { name: "React & JavaScript", level: 80 },
        { name: "Database Management", level: 82 }
      ]
    },
    {
      title: "Professional & Leadership",
      icon: Users,
      color: "from-purple-500 to-pink-600",
      skills: [
        { name: "Team Leadership", level: 95 },
        { name: "Operational Coordination", level: 92 },
        { name: "Project Management", level: 88 },
        { name: "Organizational Development", level: 90 },
        { name: "Communication Skills", level: 91 }
      ]
    },
    {
      title: "Technical Tools & Systems",
      icon: Monitor,
      color: "from-orange-500 to-red-600",
      skills: [
        { name: "IoT Development", level: 86 },
        { name: "Predictive Maintenance", level: 83 },
        { name: "Data Analytics", level: 87 },
        { name: "Arduino/Microcontrollers", level: 89 },
        { name: "TensorFlow", level: 82 }
      ]
    }
  ];

  const communicationSkills = [
    { skill: "Technical Communication", description: "Ability to explain complex technical concepts clearly" },
    { skill: "Cross-functional Collaboration", description: "Experience working with diverse teams and stakeholders" },
    { skill: "Presentation Skills", description: "Confident in presenting ideas and project outcomes" },
    { skill: "Documentation", description: "Strong technical writing and documentation abilities" }
  ];

  return (
    <section className="py-20 bg-background tech-pattern">
      <div className="max-w-6xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl lg:text-4xl mb-6 text-foreground">Skills & Expertise</h2>
          <div className="w-20 h-1 bg-tech-blue-700 mx-auto mb-8 tech-glow"></div>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            A comprehensive skill set spanning electrical engineering, programming, organizational leadership, 
            and cutting-edge technology applications.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {skillCategories.map((category, categoryIndex) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: categoryIndex * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="p-6 h-full bg-card border-0 tech-shadow neon-border">
                <div className="flex items-center gap-3 mb-6">
                  <div className={`w-10 h-10 bg-gradient-to-r ${category.color} rounded-lg flex items-center justify-center tech-glow`}>
                    <category.icon className="w-5 h-5 text-white" />
                  </div>
                  <h3 className="text-xl text-card-foreground">{category.title}</h3>
                </div>
                
                <div className="space-y-4">
                  {category.skills.map((skill, skillIndex) => (
                    <motion.div
                      key={skill.name}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.4, delay: skillIndex * 0.1 }}
                      viewport={{ once: true }}
                    >
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-muted-foreground">{skill.name}</span>
                        <span className="text-sm text-tech-blue-800">{skill.level}%</span>
                      </div>
                      <Progress value={skill.level} className="h-2" />
                    </motion.div>
                  ))}
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          viewport={{ once: true }}
        >
          <Card className="p-8 bg-card border-0 tech-shadow neon-border">
            <div className="flex items-center gap-3 mb-8 justify-center">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center tech-glow">
                <MessageSquare className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl text-card-foreground">Communication & Collaboration</h3>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              {communicationSkills.map((item, index) => (
                <motion.div
                  key={item.skill}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="flex items-start gap-4 p-4 tech-gradient-accent rounded-lg hover:bg-tech-blue-300 transition-colors duration-300"
                >
                  <div className="w-8 h-8 bg-tech-blue-200 rounded-full flex items-center justify-center flex-shrink-0 mt-1 tech-glow">
                    <Wrench className="w-4 h-4 text-tech-blue-800" />
                  </div>
                  <div>
                    <h4 className="text-base mb-2 text-card-foreground">{item.skill}</h4>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}